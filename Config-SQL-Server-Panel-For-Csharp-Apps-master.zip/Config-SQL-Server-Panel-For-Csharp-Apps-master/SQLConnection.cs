﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Config_SQL_Server_For_Apps
{
   public static class SQLConnection
    {
        public static string ConnectionString { get; set; }
    }
}
